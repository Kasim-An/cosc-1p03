package Assign_3;

/* index out of bounds error occurs when the specified index is less than 0 
 or greater then the length of the sequence*/

public class IndexOutOfBoundsException extends RuntimeException { }
//Xinan Wang No.5535802