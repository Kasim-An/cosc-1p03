package Assign_2;

 class Node {

  Word item;
  Node next;

  
  Node( Word c, Node n)
  {
   
   item = c;
   next = n;
   
  }
  
  
}//Node
//xinan wang NO.5535802
